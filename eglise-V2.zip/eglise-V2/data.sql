CREATE DATABASE eglises_mada;
\c eglises_mada;
CREATE EXTENSION postgis;

ogr2ogr -f "PostgreSQL" PG:"dbname=eglises_mada user=postgres password=12033" \
  F:/ITUniversity/Semestre_4/SIG/madagascar-churches/Fiangonana.geojson \
  -nln eglises \
  -nlt POINT \
  -lco GEOMETRY_NAME=geom \
  -lco FID=gid \
  -lco SPATIAL_INDEX=GIST \
  -overwrite

DROP DATABASE IF EXISTS madagascar_churches;

CREATE DATABASE madagascar_churches;

\c madagascar_churches;



CREATE EXTENSION postgis;



-- Table des provinces

CREATE TABLE provinces

(

    id   SERIAL PRIMARY KEY,

    nom  TEXT,

    geom geometry(MultiPolygon, 4326)

);

CREATE INDEX idx_provinces_geom ON provinces USING GIST (geom);



-- Table des régions

CREATE TABLE regions

(

    id   SERIAL PRIMARY KEY,

    nom  TEXT,

    geom geometry(MultiPolygon, 4326)

);

CREATE INDEX idx_regions_geom ON regions USING GIST (geom);



-- Table des districts

CREATE TABLE districts

(

    id   SERIAL PRIMARY KEY,

    nom  TEXT,

    geom geometry(MultiPolygon, 4326)

);

CREATE INDEX idx_districts_geom ON districts USING GIST (geom);



-- Table des communes

CREATE TABLE communes

(

    id   SERIAL PRIMARY KEY,

    nom  TEXT,

    geom geometry(MultiPolygon, 4326)

);

CREATE INDEX idx_communes_geom ON communes USING GIST (geom);



-- Table des églises

CREATE TABLE eglises

(

    id              SERIAL PRIMARY KEY,

    nom             TEXT,

    denomination    TEXT,

    annee_fondation INTEGER,

    province        TEXT,

    region          TEXT,

    district        TEXT,

    commune         TEXT,

    created_at      TIMESTAMP DEFAULT now(),

    geom            geometry(Point, 4326)

);

CREATE INDEX idx_eglises_geom ON eglises USING GIST (geom);