<h1>Importer des Églises</h1>
<?php if (!empty($error)): ?>
    <div style="color:red"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>
<form action="/admin/eglises/import" method="post" enctype="multipart/form-data">
    <label>Type de fichier :</label>
    <select name="type">
        <option value="csv">CSV</option>
        <option value="geojson">GeoJSON</option>
    </select><br>
    <input type="file" name="file" required><br>
    <button type="submit">Importer</button>
</form>
<a href="/admin/eglises">Retour à la liste</a>