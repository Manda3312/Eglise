
<!-- filepath: f:\ITUniversity\Semestre_4\SIG\eglise\app\views\eglises\map.php -->
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Carte des Églises de Madagascar</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css"/>
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
    <style>
        html, body { height: 100%; margin: 0; padding: 0; }
        body, #map { height: 100vh; width: 100vw; }
        #top-bar {
            position: absolute; top: 0; left: 0; right: 0; z-index: 1001;
            background: rgba(255,255,255,0.97); padding: 10px 10px 5px 10px;
            display: flex; align-items: center; gap: 10px; box-shadow: 0 2px 8px #0002;
        }
        #side-list {
            position: absolute; top: 60px; left: 0; bottom: 0; width: 350px; max-width: 90vw;
            background: #f8f8f8; border-right: 1px solid #ccc; box-shadow: 2px 0 8px #0001;
            z-index: 1002; overflow-y: auto; transition: transform 0.3s;
        }
        #side-list.closed { transform: translateX(-100%); }
        #side-list .close-btn {
            position: absolute; top: 8px; right: 8px; background: #eee; border: none;
            font-size: 18px; cursor: pointer; border-radius: 50%; width: 28px; height: 28px;
        }
        #side-list .eglise-item {
            background: #fff; border: 1px solid #ddd; border-radius: 6px; margin-bottom: 10px;
            padding: 8px; box-shadow: 0 1px 2px #eee; cursor: pointer;
        }
        #side-list .eglise-item.selected { background: #cce5ff; }
        #side-list .eglise-item button { margin-right: 5px; margin-top: 5px; }
        #open-list-btn {
            position: absolute; top: 80px; left: 0; z-index: 1003; background: #1976d2; color: #fff;
            border: none; border-radius: 0 20px 20px 0; font-size: 22px; padding: 6px 12px 6px 8px;
            cursor: pointer; box-shadow: 2px 2px 8px #0002; display: none;
        }
        #open-list-btn.visible { display: block; }
        #map { height: 100vh; width: 100vw; z-index: 1; }
        #layer-switcher {
            position: absolute; bottom: 20px; right: 20px; z-index: 1004; background: #fff;
            border-radius: 8px; box-shadow: 0 2px 8px #0002; padding: 6px 10px;
            display: flex; gap: 10px; align-items: center;
        }
        #layer-switcher button {
            border: none; background: #eee; border-radius: 4px; padding: 4px 10px;
            cursor: pointer; font-weight: bold;
        }
        #layer-switcher button.active { background: #1976d2; color: #fff; }
        @media (max-width: 600px) { #side-list { width: 95vw; } }
    </style>
</head>
<body>
    <div id="top-bar">
        <form id="search-form" style="display:flex;gap:10px;align-items:center;margin:0;">
            <input type="text" name="search" id="search-input" placeholder="Recherche texte..." value="">
            <select name="religion" id="religion-select">
                <option value="">Toutes religions</option>
                <?php foreach ($religions as $religion): ?>
                    <option value="<?= ($religion) ?>"><?= ($religion) ?></option>
                <?php endforeach; ?>
            </select>
            <select name="denomination" id="denomination-select">
                <option value="">Toutes dénominations</option>
                <?php foreach ($denominations as $denomination): ?>
                    <option value="<?= ($denomination) ?>"><?= ($denomination) ?></option>
                <?php endforeach; ?>
            </select>
            <input type="number" min="0" step="1" name="radius" id="radius-input" placeholder="Rayon (km)" style="width:110px;">
            <button type="button" id="btn-filtrer">Rechercher</button>
        </form>
    </div>
    <div id="side-list" class="closed">
        <button class="close-btn" title="Fermer la liste">&times;</button>
        <h3>Résultats (<span id="result-count"></span>)</h3>
        <div id="eglise-list"></div>
    </div>
    <button id="open-list-btn" class="visible" title="Ouvrir la liste">&#x25B6;</button>
    <div id="map"></div>
    <div id="layer-switcher">
        <button id="normal-btn" class="active">Normal</button>
        <button id="satellite-btn">Satellite</button>
    </div>
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <script>
        // --- Initialisation ---
        var map = L.map('map', { zoomControl: false }).setView([-18.9859947, 47.5302228], 16);
        L.control.zoom({ position: 'topright' }).addTo(map);

        var normalLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            attribution: '&copy; OpenStreetMap contributors'
        });
        var satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri'
        });
        normalLayer.addTo(map);

        document.getElementById('normal-btn').onclick = function() {
            map.removeLayer(satelliteLayer);
            map.addLayer(normalLayer);
            this.classList.add('active');
            document.getElementById('satellite-btn').classList.remove('active');
        };
        document.getElementById('satellite-btn').onclick = function() {
            map.removeLayer(normalLayer);
            map.addLayer(satelliteLayer);
            this.classList.add('active');
            document.getElementById('normal-btn').classList.remove('active');
        };

        var crossIcon = L.icon({
            iconUrl: 'https://cdn.jsdelivr.net/gh/pointhi/leaflet-color-markers@master/img/marker-icon-grey.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowUrl: 'https://unpkg.com/leaflet@1.7.1/dist/images/marker-shadow.png',
            shadowSize: [41, 41]
        });

        var allEglises = <?= json_encode($allEglises ?? $eglises) ?>;
        var markers = {};
        var itineraireActiveGid = null;
        var userLat = null, userLng = null;
        var routingControl = null;
        var userMarker = null, destMarker = null;
        var filteredEglises = allEglises.slice();
        var mode = "all"; // "all", "search", "radius"

        // --- Géolocalisation utilisateur ---
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function(position) {
                userLat = position.coords.latitude;
                userLng = position.coords.longitude;
                map.setView([userLat, userLng], 14);
                if (!userMarker) {
                    userMarker = L.marker([userLat, userLng]).addTo(map).bindPopup("Vous êtes ici");
                }
            });
        }

        // --- Outils ---
        function getDistanceKm(lat1, lng1, lat2, lng2) {
            var R = 6371;
            var dLat = (lat2 - lat1) * Math.PI / 180;
            var dLng = (lng2 - lng1) * Math.PI / 180;
            var a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLng/2) * Math.sin(dLng/2);
            var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }

        // --- Affichage des résultats dans la grille ---
        function updateList(eglises) {
            var list = document.getElementById('eglise-list');
            var count = document.getElementById('result-count');
            list.innerHTML = '';
            if (!eglises || eglises.length === 0) {
                count.textContent = 0;
                list.innerHTML = '<div style="color:#888;text-align:center;margin-top:40px;">Aucun résultat</div>';
                return;
            }
            count.textContent = eglises.length;
            eglises.forEach(function(e) {
                var div = document.createElement('div');
                div.className = 'eglise-item';
                div.setAttribute('data-gid', e.gid);
                div.innerHTML =
                    '<strong>' + e.name + '</strong><br>' +
                    e.religion + ' | ' + e.denomination + '<br>' +
                    '<button class="voir-btn" data-gid="' + e.gid + '">Voir</button>' +
                    '<button class="itineraire-btn" data-gid="' + e.gid + '" data-lat="' + e.latitude + '" data-lng="' + e.longitude + '">Itinéraire</button>';
                list.appendChild(div);
            });
            addVoirListeners();
            addItineraireListeners();
        }

        // --- Affichage des marqueurs selon recherche et rayon ---
        function showMarkers() {
            Object.values(markers).forEach(function(marker) { map.removeLayer(marker); });
            markers = {};
            if (window.radiusCircle) { map.removeLayer(window.radiusCircle); window.radiusCircle = null; }

            // Récupère les valeurs du formulaire
            var search = document.getElementById('search-input').value.trim().toLowerCase();
            var religion = document.getElementById('religion-select').value;
            var denomination = document.getElementById('denomination-select').value;
            var radius = parseFloat(document.getElementById('radius-input').value);

            // Filtrage combiné
            var result = allEglises.filter(function(e) {
                var match = true;
                if (search && !(e.name && e.name.toLowerCase().includes(search))) match = false;
                if (religion && e.religion !== religion) match = false;
                if (denomination && e.denomination !== denomination) match = false;
                if (!isNaN(radius) && radius > 0 && userLat && userLng) {
                    var dist = getDistanceKm(userLat, userLng, e.latitude, e.longitude);
                    if (dist > radius) match = false;
                }
                return match;
            });

            // Affiche le cercle de rayon si demandé
            if (!isNaN(radius) && radius > 0 && userLat && userLng) {
                window.radiusCircle = L.circle([userLat, userLng], {
                    radius: radius * 1000,
                    color: "#1976d2",
                    fillColor: "#1976d2",
                    fillOpacity: 0.08
                }).addTo(map);
            }

            result.forEach(function(e) {
                if(e.latitude && e.longitude) {
                    var marker = L.marker([e.latitude, e.longitude], {icon: crossIcon}).addTo(map);
                    var popupContent =
                        "<strong>" + e.name + "</strong><br>" +
                        "Religion : " + e.religion + "<br>" +
                        "Dénomination : " + e.denomination + "<br>" +
                        "Longitude : " + e.longitude + "<br>" +
                        "Latitude : " + e.latitude + "<br>" +
                        "<button onclick='showRoute(" + e.latitude + "," + e.longitude + ",\"" + e.gid + "\")'>Itinéraire</button>";
                    marker.bindPopup(popupContent);
                    markers[e.gid] = marker;
                }
            });
            updateList(result);
        }

        // --- Recherche et filtrage combiné ---
        document.getElementById('btn-filtrer').onclick = function() {
            showMarkers();
            closeList();
            openList();
        };

        // --- Listes dynamiques ---
        function openList() {
            document.getElementById('side-list').classList.remove('closed');
            document.getElementById('open-list-btn').classList.remove('visible');
            document.getElementById('map').style.width = '';
        }
        function closeList() {
            document.getElementById('side-list').classList.add('closed');
            document.getElementById('open-list-btn').classList.add('visible');
            document.getElementById('map').style.width = '100vw';
            setTimeout(function(){ map.invalidateSize(); }, 350);
        }
        document.querySelector('#side-list .close-btn').onclick = closeList;
        document.getElementById('open-list-btn').onclick = openList;

        // --- Boutons Voir ---
        function addVoirListeners() {
            document.querySelectorAll('.voir-btn').forEach(function(btn) {
                btn.onclick = function() {
                    var gid = this.getAttribute('data-gid');
                    var marker = markers[gid];
                    if(marker) {
                        map.setView(marker.getLatLng(), 16);
                        marker.openPopup();
                        document.querySelectorAll('.eglise-item').forEach(div => div.classList.remove('selected'));
                        this.parentNode.classList.add('selected');
                    }
                    if(itineraireActiveGid) {
                        clearItineraire();
                    }
                };
            });
        }

        // --- Boutons Itinéraire ---
        function addItineraireListeners() {
            document.querySelectorAll('.itineraire-btn').forEach(function(btn) {
                btn.onclick = function() {
                    var gid = this.getAttribute('data-gid');
                    var lat = parseFloat(this.getAttribute('data-lat'));
                    var lng = parseFloat(this.getAttribute('data-lng'));
                    if(itineraireActiveGid === gid) {
                        clearItineraire();
                        return;
                    }
                    showRoute(lat, lng, gid);
                };
            });
        }

        // --- Annulation itinéraire ---
        function clearItineraire() {
            itineraireActiveGid = null;
            if (routingControl) {
                map.removeControl(routingControl);
                routingControl = null;
            }
            if (userMarker) { map.removeLayer(userMarker); userMarker = null; }
            if (destMarker) { map.removeLayer(destMarker); destMarker = null; }
            map.closePopup();
            if (map._layers) {
                Object.values(map._layers).forEach(function(layer) {
                    if (layer instanceof L.Polyline && !(layer instanceof L.Polygon)) {
                        map.removeLayer(layer);
                    }
                });
            }
            showMarkers();
            if (userLat && userLng) {
                map.setView([userLat, userLng], 14);
                userMarker = L.marker([userLat, userLng]).addTo(map).bindPopup("Vous êtes ici");
            }
        }

        // --- Fonction d'itinéraire ---
        window.showRoute = function(destLat, destLng, gid) {
            if (!userLat || !userLng) {
                alert("Activez la géolocalisation pour utiliser l'itinéraire !");
                return;
            }
            itineraireActiveGid = gid;
            Object.values(markers).forEach(function(marker) {
                map.removeLayer(marker);
            });
            if (userMarker) map.removeLayer(userMarker);
            userMarker = L.marker([userLat, userLng]).addTo(map).bindPopup("Vous êtes ici");
            if (destMarker) map.removeLayer(destMarker);
            destMarker = L.marker([destLat, destLng], {icon: crossIcon}).addTo(map);

            if (routingControl) {
                map.removeControl(routingControl);
                routingControl = null;
            }

            routingControl = L.Routing.control({
                waypoints: [
                    L.latLng(userLat, userLng),
                    L.latLng(destLat, destLng)
                ],
                routeWhileDragging: false,
                draggableWaypoints: false,
                addWaypoints: false,
                show: false,
                router: L.Routing.osrmv1({
                    serviceUrl: 'https://router.project-osrm.org/route/v1'
                }),
                lineOptions: {
                    styles: [{color: '#1976d2', weight: 7, opacity: 1}]
                },
                createMarker: function() { return null; }
            })
            .on('routesfound', function(e) {
                if (routingControl._alternativesLayer) {
                    routingControl._alternativesLayer.clearLayers();
                }
                var routes = e.routes;
                for (var i = 0; i < routes.length; i++) {
                    var color = (i === 0) ? '#1976d2' : '#90caf9';
                    var weight = (i === 0) ? 7 : 4;
                    var opacity = (i === 0) ? 1 : 0.7;
                    var line = L.polyline(routes[i].coordinates, {
                        color: color,
                        weight: weight,
                        opacity: opacity,
                        dashArray: (i === 0) ? null : '6, 12'
                    }).addTo(map);
                    if (!routingControl._alternativesLayer) routingControl._alternativesLayer = L.layerGroup().addTo(map);
                    routingControl._alternativesLayer.addLayer(line);

                    if(i === 0) {
                        var summary = routes[i].summary;
                        var distanceKm = (summary.totalDistance / 1000).toFixed(2) + " km";
                        var durationMin = Math.round(summary.totalTime / 60) + " min (voiture)";
                        var walkTimeMin = Math.round((summary.totalDistance / 1000) / 5 * 60) + " min (à pied)";
                        var midIdx = Math.floor(routes[i].coordinates.length / 2);
                        var midLatLng = routes[i].coordinates[midIdx];
                        L.popup({closeOnClick: false, autoClose: false})
                            .setLatLng(midLatLng)
                            .setContent(
                                "<b>Distance :</b> " + distanceKm + "<br>" +
                                "<b>Durée :</b> " + durationMin + "<br>" +
                                "<b>À pied :</b> " + walkTimeMin
                            )
                            .openOn(map);

                        var bounds = L.latLngBounds([ [userLat, userLng], [destLat, destLng] ]);
                        map.fitBounds(bounds, {padding: [80, 80]});
                    }
                }
                if (destMarker) {
                    var markerPopup =
                        "<strong>Itinéraire vers cette église</strong><br>" +
                        "<button onclick='clearItineraire()'>Annuler</button>";
                    destMarker.bindPopup(markerPopup).openPopup();
                }
            })
            .addTo(map);
        };

        // --- Initialisation : affiche tout sans filtrage par rayon ---
        window.addEventListener('DOMContentLoaded', function() {
            document.getElementById('search-input').value = '';
            document.getElementById('religion-select').selectedIndex = 0;
            document.getElementById('denomination-select').selectedIndex = 0;
            document.getElementById('radius-input').value = '';
            mode = "all";
            showMarkers();
        });

    </script>
</body>
</html>