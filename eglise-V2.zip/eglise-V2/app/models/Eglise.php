<?php

namespace app\models;

use PDO;

class Eglise
{
    protected $db;

    public function __construct($db)
    {
        $this->db = $db;
    }

    public function getAll()
    {
        $sql = "SELECT gid, name, religion, denomination, ST_X(geom) AS longitude, ST_Y(geom) AS latitude FROM eglises";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

public function getById($id)
{
    $sql = "SELECT gid, name, religion, denomination, ST_X(geom) AS longitude, ST_Y(geom) AS latitude FROM eglises WHERE gid = :id";
    $stmt = $this->db->prepare($sql);
    $stmt->execute(['id' => $id]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}
public function insert($data)
{
    $sql = "INSERT INTO eglises (name, religion, denomination, geom) VALUES (:name, :religion, :denomination, ST_GeomFromText(:geom))";
    $stmt = $this->db->prepare($sql);
    return $stmt->execute($data);
}

public function update($id, $data)
{
    $sql = "UPDATE eglises SET name = :name, religion = :religion, denomination = :denomination, geom = ST_GeomFromText(:geom) WHERE gid = :id";
    $stmt = $this->db->prepare($sql);
    $data['id'] = $id;
    return $stmt->execute($data);
}

public function delete($id)
{
    $sql = "DELETE FROM eglises WHERE gid = :id";
    $stmt = $this->db->prepare($sql);
    return $stmt->execute(['id' => $id]);
}

public function getAllReligions()
{
    $sql = "SELECT DISTINCT religion FROM eglises ORDER BY religion";
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

public function getAllDenominations()
{
    $sql = "SELECT DISTINCT denomination FROM eglises ORDER BY denomination";
    $stmt = $this->db->prepare($sql);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}
public function search($filters)
{
    $sql = "SELECT gid, name, religion, denomination, ST_X(geom) AS longitude, ST_Y(geom) AS latitude FROM eglises WHERE 1=1";
    $params = [];

    if (!empty($filters['search'])) {
        $sql .= " AND (name ILIKE :search OR religion ILIKE :search OR denomination ILIKE :search)";
        $params['search'] = '%' . $filters['search'] . '%';
    }
    if (!empty($filters['religion'])) {
        $sql .= " AND religion = :religion";
        $params['religion'] = $filters['religion'];
    }
    if (!empty($filters['denomination'])) {
        $sql .= " AND denomination = :denomination";
        $params['denomination'] = $filters['denomination'];
    }

    $stmt = $this->db->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(\PDO::FETCH_ASSOC);
}
}