<?php
namespace app\controllers;

use app\models\Eglise;

class AdminEgliseController
{
    protected $app;
    protected $egliseModel;

    public function __construct($app)
    {
        $this->app = $app;
        $this->egliseModel = new Eglise(($app->get('db'))());
    }
public function adminIndex()
{
    $filters = [
        'search' => $_GET['search'] ?? '',
        'religion' => $_GET['religion'] ?? '',
        'denomination' => $_GET['denomination'] ?? ''
    ];

    $eglises = $this->egliseModel->search($filters);
    $religions = $this->egliseModel->getAllReligions();
    $denominations = $this->egliseModel->getAllDenominations();

    $this->app->render('admin/list', [
        'eglises' => $eglises,
        'filters' => $filters,
        'religions' => $religions,
        'denominations' => $denominations
    ]);
}
    public function createForm()
    {
        $this->app->render('admin/form');
    }

public function store()
{
    $longitude = trim($_POST['longitude']);
    $latitude = trim($_POST['latitude']);
    if (!is_numeric($longitude) || !is_numeric($latitude)) {
        $this->app->render('admin/form', [
            'error' => "Longitude et latitude doivent être des nombres.",
            'eglise' => $_POST
        ]);
        return;
    }
    $geom = "POINT($longitude $latitude)";
    $data = [
        'name' => $_POST['name'],
        'religion' => $_POST['religion'],
        'denomination' => $_POST['denomination'],
        'geom' => $geom
    ];
    $this->egliseModel->insert($data);
    $this->app->redirect('/admin/eglises');
}

    public function editForm($id)
    {
        $eglise = $this->egliseModel->getById($id);
        $this->app->render('admin/form', ['eglise' => $eglise]);
    }

public function update($id)
{
    $longitude = trim($_POST['longitude']);
    $latitude = trim($_POST['latitude']);
    if (!is_numeric($longitude) || !is_numeric($latitude)) {
        $eglise = $this->egliseModel->getById($id);
        $this->app->render('admin/form', [
            'error' => "Longitude et latitude doivent être des nombres.",
            'eglise' => array_merge($eglise, $_POST)
        ]);
        return;
    }
    $geom = "POINT($longitude $latitude)";
    $data = [
        'name' => $_POST['name'],
        'religion' => $_POST['religion'],
        'denomination' => $_POST['denomination'],
        'geom' => $geom
    ];
    $this->egliseModel->update($id, $data);
    $this->app->redirect('/admin/eglises');
}
    public function delete($id)
    {
        $this->egliseModel->delete($id);
        $this->app->redirect('/admin/eglises');
    }

    public function show($id)
    {
        $eglise = $this->egliseModel->getById($id);
        $this->app->render('admin/detail', ['eglise' => $eglise]);
    }
public function importForm()
{
    $this->app->render('admin/import');
}

public function import()
{
    if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
        $this->app->render('admin/import', ['error' => 'Erreur lors de l\'upload du fichier.']);
        return;
    }
    $file = $_FILES['file']['tmp_name'];
    $type = $_POST['type'] ?? 'csv';

    if ($type === 'csv') {
        $handle = fopen($file, 'r');
        $header = fgetcsv($handle);
        while (($row = fgetcsv($handle)) !== false) {
            $data = array_combine($header, $row);
            if (isset($data['longitude'], $data['latitude'])) {
                $data['geom'] = "POINT({$data['longitude']} {$data['latitude']})";
                $this->egliseModel->insert($data);
            }
        }
        fclose($handle);
    } elseif ($type === 'geojson') {
        $geojson = json_decode(file_get_contents($file), true);
        foreach ($geojson['features'] as $feature) {
            $props = $feature['properties'];
            $coords = $feature['geometry']['coordinates'];
            $props['geom'] = "POINT({$coords[0]} {$coords[1]})";
            $this->egliseModel->insert($props);
        }
    }
    $this->app->redirect('/admin/eglises');
}
public function exportCsv()
{
    $eglises = $this->egliseModel->getAll();
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="eglises.csv"');
    $out = fopen('php://output', 'w');
    if (!empty($eglises)) {
        fputcsv($out, array_keys($eglises[0]));
        foreach ($eglises as $eglise) {
            fputcsv($out, $eglise);
        }
    }
    fclose($out);
    exit;
}

public function exportGeojson()
{
    $eglises = $this->egliseModel->getAll();
    $features = [];
    foreach ($eglises as $e) {
        $features[] = [
            'type' => 'Feature',
            'geometry' => [
                'type' => 'Point',
                'coordinates' => [floatval($e['longitude']), floatval($e['latitude'])]
            ],
            'properties' => [
                'gid' => $e['gid'],
                'name' => $e['name'],
                'religion' => $e['religion'],
                'denomination' => $e['denomination']
            ]
        ];
    }
    $geojson = [
        'type' => 'FeatureCollection',
        'features' => $features
    ];
    header('Content-Type: application/json');
    header('Content-Disposition: attachment; filename="eglises.geojson"');
    echo json_encode($geojson, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}
}