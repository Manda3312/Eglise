<?php

use flight\Engine;
use flight\net\Router;

use app\controllers\EgliseController;

use app\controllers\AdminEgliseController;


// ...existing code...


// ...existing code...

/** 
 * @var Router $router 
 * @var Engine $app
 */
/*$router->get('/', function() use ($app) {
	$Welcome_Controller = new WelcomeController($app);
	$app->render('welcome', [ 'message' => 'It works!!' ]);
});*/

$Eglise_Controller = new EgliseController($app);
$router->get('/eglises', [ $Eglise_Controller, 'index' ]);
$router->get('/carte-eglises', [ $Eglise_Controller, 'map' ]);

$AdminEglise_Controller = new AdminEgliseController($app);
$router->get('/admin/eglises', [ $AdminEglise_Controller, 'adminIndex' ]);
$router->get('/admin/eglises/create', [ $AdminEglise_Controller, 'createForm' ]);
$router->post('/admin/eglises', [ $AdminEglise_Controller, 'store' ]);
$router->get('/admin/eglises/@id/edit', [ $AdminEglise_Controller, 'editForm' ]);
$router->post('/admin/eglises/@id', [ $AdminEglise_Controller, 'update' ]);
$router->post('/admin/eglises/@id/delete', [ $AdminEglise_Controller, 'delete' ]);
$router->get('/eglise/@id', [ $AdminEglise_Controller, 'show' ]);
$router->get('/admin/eglises/import', [ $AdminEglise_Controller, 'importForm' ]);
$router->post('/admin/eglises/import', [ $AdminEglise_Controller, 'import' ]);
// ...existing code.
$router->get('/admin/eglises/export/csv', [ $AdminEglise_Controller, 'exportCsv' ]);
$router->get('/admin/eglises/export/geojson', [ $AdminEglise_Controller, 'exportGeojson' ]);