<!DOCTYPE html>
<html>
<head>
    <title>Liste des Églises</title>
</head>
<body>
    <h1>Liste des Églises</h1>
    <table border="1">
        <tr>
            <th>gid</th>
            <th>Nom</th>
            <th>Religion</th>
            <th>Dénomination</th>
            <th>Longitude</th>
            <th>Latitude</th>
        </tr>
        <?php foreach ($eglises as $eglise): ?>
        <tr>
            <td><?= htmlspecialchars($eglise['gid']) ?></td>
            <td><?= ($eglise['name']) ?></td>
            <td><?= ($eglise['religion']) ?></td>
            <td><?= ($eglise['denomination']) ?></td>
            <td><?= htmlspecialchars($eglise['longitude']) ?></td>
            <td><?= htmlspecialchars($eglise['latitude']) ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>