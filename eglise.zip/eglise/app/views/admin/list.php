
<h1>Liste des Églises</h1>
<a href="/admin/eglises/create">Ajouter une église</a>

<!-- Ajoute ceci en haut de la page -->
<a href="/admin/eglises/export/csv">Exporter CSV</a> |
<a href="/admin/eglises/export/geojson">Exporter GeoJSON</a>
<form method="get" action="/admin/eglises" style="margin-bottom:20px;">
    <input type="text" name="search" placeholder="Recherche texte..." value="<?= htmlspecialchars($filters['search'] ?? '') ?>">
    <select name="religion">
        <option value="">Toutes religions</option>
        <?php foreach ($religions as $religion): ?>
            <option value="<?= ($religion) ?>" <?= ($filters['religion'] ?? '') === $religion ? 'selected' : '' ?>>
                <?= ($religion) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <select name="denomination">
        <option value="">Toutes dénominations</option>
        <?php foreach ($denominations as $denomination): ?>
            <option value="<?= ($denomination) ?>" <?= ($filters['denomination'] ?? '') === $denomination ? 'selected' : '' ?>>
                <?= ($denomination) ?>
            </option>
        <?php endforeach; ?>
    </select>
    <button type="submit">Filtrer</button>
</form>

<table border="1" cellpadding="5">
    <tr>
        <th>ID</th>
        <th>Nom</th>
        <th>Religion</th>
        <th>Dénomination</th>
        <th>Longitude</th>
        <th>Latitude</th>
        <th>Actions</th>
    </tr>
    <?php foreach ($eglises as $eglise): ?>
    <tr>
        <td><?= htmlspecialchars($eglise['gid']) ?></td>
        <td><?= ($eglise['name']) ?></td>
        <td><?= ($eglise['religion']) ?></td>
        <td><?= ($eglise['denomination']) ?></td>
        <td><?= htmlspecialchars($eglise['longitude']) ?></td>
        <td><?= htmlspecialchars($eglise['latitude']) ?></td>
        <td>
            <a href="/eglise/<?= $eglise['gid'] ?>">Voir</a> |
            <a href="/admin/eglises/<?= $eglise['gid'] ?>/edit">Modifier</a> |
            <form action="/admin/eglises/<?= $eglise['gid'] ?>/delete" method="post" style="display:inline;" onsubmit="return confirm('Supprimer cette église ?');">
                <button type="submit">Supprimer</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
