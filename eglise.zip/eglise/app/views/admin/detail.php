
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
</body>
</html>
<h1>Détail de l'Église</h1>
<ul>
    <li><strong>ID :</strong> <?= htmlspecialchars($eglise['gid']) ?></li>
    <li><strong>Nom :</strong> <?= ($eglise['name']) ?></li>
    <li><strong>Religion :</strong> <?= ($eglise['religion']) ?></li>
    <li><strong>Dénomination :</strong> <?= ($eglise['denomination']) ?></li>

<li><strong>Longitude :</strong> <?= isset($eglise['longitude']) ? ($eglise['longitude']) : '' ?></li>
<li><strong>Latitude :</strong> <?= isset($eglise['latitude']) ? ($eglise['latitude']) : '' ?></li> 
</ul>
<a href="/admin/eglises">Retour à la liste</a>