<?php
$isEdit = isset($eglise);
$action = $isEdit ? "/admin/eglises/{$eglise['gid']}" : "/admin/eglises";
$method = $isEdit ? "post" : "post";
$longitude = $isEdit ? ($eglise['longitude'] ?? '') : '';
$latitude = $isEdit ? ($eglise['latitude'] ?? '') : '';
?>
<h1><?= $isEdit ? 'Modifier' : 'Ajouter' ?> une Église</h1>
<form action="<?= $action ?>" method="post">
    <label>Nom :</label>
    <input type="text" name="name" value="<?= $isEdit ? ($eglise['name']) : '' ?>" required><br>
    <label>Religion :</label>
    <input type="text" name="religion" value="<?= $isEdit ? ($eglise['religion']) : '' ?>" required><br>
    <label>Dénomination :</label>
    <input type="text" name="denomination" value="<?= $isEdit ? htmlspecialchars($eglise['denomination']) : '' ?>"><br>
    <label>Longitude :</label>
    <input type="text" name="longitude" value="<?= htmlspecialchars($longitude) ?>" required><br>
    <label>Latitude :</label>
    <input type="text" name="latitude" value="<?= htmlspecialchars($latitude) ?>" required><br>
    <button type="submit"><?= $isEdit ? 'Enregistrer' : 'Ajouter' ?></button>
</form>
<a href="/admin/eglises">Retour à la liste</a>