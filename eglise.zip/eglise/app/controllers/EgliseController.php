<?php
namespace app\controllers;

use app\models\Eglise;

class EgliseController
{
    protected $app;
    protected $egliseModel;

    public function __construct($app)
    {
        $this->app = $app;
        $this->egliseModel = new Eglise(($app->get('db'))());
    }

    public function index()
    {
        $eglises = $this->egliseModel->getAll();
        $this->app->render('eglises/index', ['eglises' => $eglises]);   
    }
    public function map()
{
    $filters = [
        'search' => $_GET['search'] ?? '',
        'religion' => $_GET['religion'] ?? '',
        'denomination' => $_GET['denomination'] ?? '',
    ];
    $eglises = $this->egliseModel->search($filters);
    $religions = $this->egliseModel->getAllReligions();
    $denominations = $this->egliseModel->getAllDenominations();

    $this->app->render('eglises/map', [
        'eglises' => $eglises,
        'filters' => $filters,
        'religions' => $religions,
        'denominations' => $denominations,
        // On passe aussi toutes les églises pour la carte
        'allEglises' => $this->egliseModel->getAll()
    ]);
}
}