CREATE DATABASE eglises_mada;
\c eglises_mada;
CREATE EXTENSION postgis;

ogr2ogr -f "PostgreSQL" PG:"dbname=eglises_mada user=postgres password=12033" \
  F:/ITUniversity/Semestre_4/SIG/madagascar-churches/Fiangonana.geojson \
  -nln eglises \
  -nlt POINT \
  -lco GEOMETRY_NAME=geom \
  -lco FID=gid \
  -lco SPATIAL_INDEX=GIST \
  -overwrite
